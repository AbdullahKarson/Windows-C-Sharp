﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace NoteBookUnitTester
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }

        [TestMethod]
        public void TestMethod2()
        {
        }
    }
}
